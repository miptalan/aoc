package com.b2c2.takehometask.model;

import java.time.LocalDateTime;
public record MarketTick(LocalDateTime timestamp, String instrumentId, double price) {}