package com.b2c2.takehometask.model;

public enum Side {BUY, SELL}