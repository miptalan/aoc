package com.b2c2.takehometask.marketdata;

public interface MarketDataSource {
    void start();
    void stop();
    void addListener(MarketDataListener listener);
}
