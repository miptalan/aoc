package com.b2c2.takehometask;

import com.b2c2.takehometask.config.RuntimeMode;
import com.b2c2.takehometask.marketdata.FileMarketDataSource;
import com.b2c2.takehometask.strategy.StrategyDispatcher;
import com.b2c2.takehometask.marketdata.MarketDataSource;
import com.b2c2.takehometask.marketdata.WebSocketMarketDataSource;
import com.b2c2.takehometask.strategy.RsiStrategy;
import com.b2c2.takehometask.trading.TradeLogger;
import com.b2c2.takehometask.trading.TradeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class App {
    private static Logger LOG = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) throws Exception {
        RuntimeMode mode = null;
        try {
            mode = RuntimeMode.valueOf(args[0].toUpperCase());
        } catch (Exception e) {
            System.err.println("Usage: java -jar strategy.jar <backtest|realtime>");
            System.exit(1);
        }

        // all hardcoded for simplicity
        // FIXME: proper app configuration,
        String historicalFilePath = "historical_prices.txt"; // Or from config
        String outputTradeLogPath = "historical_trades.txt"; // Or from config
        List<String> instruments = List.of("BTC-USD", "ETH-USD", "LTC-USD");

        int rsiPeriod = 14;
        int lowThreshold = 30;
        int highThreshold = 70;

        if (LOG.isInfoEnabled()) {
            LOG.info("Starting in {} mode for {}", mode, instruments);
        }

        TradeService tradeLogger = new TradeLogger(outputTradeLogPath);

        Map<String, RsiStrategy> strategyMap = new HashMap<>();
        for (String instrumentId : instruments) {
            RsiStrategy strategy = new RsiStrategy(instrumentId, rsiPeriod, lowThreshold, highThreshold, tradeLogger);
            strategyMap.put(instrumentId, strategy);
        }
        StrategyDispatcher dispatcher = new StrategyDispatcher(strategyMap);

        MarketDataSource marketDataSource;
        if (mode == RuntimeMode.BACKTEST) {
            marketDataSource = new FileMarketDataSource(historicalFilePath);
        } else {
            // marketDataSource = new WebSocketMarketDataSource("wss://ws-feed.exchange.coinbase.com", instruments);
            System.out.println("Realtime mode selected. Using WebSocket.");
            marketDataSource = new WebSocketMarketDataSource("wss://ws-feed.exchange.coinbase.com", instruments, dispatcher); // Corrected constructor
        }
        marketDataSource.addListener(dispatcher);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (LOG.isInfoEnabled()) {
                LOG.info("Shutting down...");
            }
            marketDataSource.stop();
            dispatcher.shutdown();
            try {
                tradeLogger.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            if (LOG.isInfoEnabled()) {
                LOG.info("Shutdown complete.");
            }
        }));

        marketDataSource.start();
        if (LOG.isInfoEnabled()) {
            LOG.info("Market data source started. Press Ctrl+C to exit.");
        }
        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            LOG.warn("Main thread interrupted, exiting");
        }
    }
}
