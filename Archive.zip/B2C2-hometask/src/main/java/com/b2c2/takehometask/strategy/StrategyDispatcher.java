package com.b2c2.takehometask.strategy;

import com.b2c2.takehometask.marketdata.MarketDataListener;
import com.b2c2.takehometask.model.MarketTick;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class StrategyDispatcher implements MarketDataListener {
    private static final Logger LOG = LoggerFactory.getLogger(StrategyDispatcher.class);

    private final Map<String, RsiStrategy> strategyMap; // instrumentId -> strategy instance
    private final ExecutorService strategyExecutor;

    public StrategyDispatcher(Map<String, RsiStrategy> strategyMap) {
        this.strategyMap = strategyMap;
        this.strategyExecutor = Executors.newFixedThreadPool(strategyMap.size());
    }

    @Override
    public void onMarketData(MarketTick quote) {
        RsiStrategy relevantStrategy = strategyMap.get(quote.instrumentId());
        if (relevantStrategy != null) {
            strategyExecutor.submit(() -> relevantStrategy.onMarketData(quote));
        }
    }

    public void shutdown() {
        if (LOG.isWarnEnabled()) {
            LOG.warn("Shutting down dispatcher with {} running strategies", strategyMap.size());
        }
        strategyExecutor.shutdown();
        try {
            if (!strategyExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                strategyExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            LOG.error("Encountered exception on shutdown, forcing", e);
            strategyExecutor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
