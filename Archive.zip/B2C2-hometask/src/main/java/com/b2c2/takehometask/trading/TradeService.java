package com.b2c2.takehometask.trading;

import com.b2c2.takehometask.model.TradeSignal;

public interface TradeService extends AutoCloseable {
    void trade(TradeSignal tradeSignal);
}
