package com.b2c2.takehometask.marketdata;

import com.b2c2.takehometask.strategy.StrategyDispatcher;

import java.util.List;

public class WebSocketMarketDataSource implements MarketDataSource {
    public WebSocketMarketDataSource(String s, List<String> instruments, StrategyDispatcher dispatcher) {
    }

    public void stop() {

    }

    @Override
    public void addListener(MarketDataListener listener) {

    }

    public void start() {

    }
}
