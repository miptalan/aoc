package com.b2c2.takehometask.config;

public enum RuntimeMode {BACKTEST, REALTIME}
