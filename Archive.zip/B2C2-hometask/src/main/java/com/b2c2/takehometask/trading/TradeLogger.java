package com.b2c2.takehometask.trading;

import com.b2c2.takehometask.model.TradeSignal;

public class TradeLogger implements TradeService, AutoCloseable {
    public TradeLogger(String outputTradeLogPath) {

    }

    @Override
    public void trade(TradeSignal tradeSignal) {

    }

    @Override
    public void close() {

    }
}
