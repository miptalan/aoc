package com.b2c2.takehometask.marketdata;

public class FileMarketDataSource implements MarketDataSource {
    public FileMarketDataSource(String historicalFilePath) {
    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }

    @Override
    public void addListener(MarketDataListener listener) {

    }
}
