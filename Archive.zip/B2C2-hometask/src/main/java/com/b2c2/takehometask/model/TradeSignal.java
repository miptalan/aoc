package com.b2c2.takehometask.model;

import java.time.LocalDateTime;

public record TradeSignal(
        LocalDateTime timestamp,
        String strategyName,
        String instrumentId,
        double rsiScore,
        Side side,
        double size, // Always 1.0 for this problem
        double price
) {
}
