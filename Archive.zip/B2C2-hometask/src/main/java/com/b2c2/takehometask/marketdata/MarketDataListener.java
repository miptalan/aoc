package com.b2c2.takehometask.marketdata;

import com.b2c2.takehometask.model.MarketTick;

public interface MarketDataListener {
    void onMarketData(MarketTick data);
}
