package com.b2c2.takehometask.strategy;

import com.b2c2.takehometask.marketdata.MarketDataListener;
import com.b2c2.takehometask.model.MarketTick;
import com.b2c2.takehometask.trading.TradeLogger;
import com.b2c2.takehometask.trading.TradeService;

public class RsiStrategy implements MarketDataListener {
    public RsiStrategy(String instrumentId,
                       int rsiPeriod, int oversoldThreshold, int overboughtThreshold,
                       TradeService tradeService) {

    }


    @Override
    public void onMarketData(MarketTick data) {

    }
}
