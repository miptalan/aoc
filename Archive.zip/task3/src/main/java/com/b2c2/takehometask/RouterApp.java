package com.b2c2.takehometask;

import com.b2c2.takehometask.api.TradeSignalEvents;
import com.b2c2.takehometask.strategy.StrategyConsumer;
import com.b2c2.takehometask.strategy.TradeSignalSink;
import com.b2c2.takehometask.transport.BacktestMarketDataPublisher;
import com.b2c2.takehometask.transport.FanOutRunnable;
import net.openhft.chronicle.queue.ChronicleQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class RouterApp {
    private static final Logger LOG = LoggerFactory.getLogger(RouterApp.class);

    public static void main(String[] args) throws Exception {
        ChronicleQueue mdQueue = ChronicleQueue.singleBuilder("queues/market-data").build();
        ChronicleQueue tsQueue = ChronicleQueue.singleBuilder("queues/trade-signals").build();

        // 1) Back‑test publisher
        String backTestFile = "historical_prices.txt";
        BacktestMarketDataPublisher publisher = new BacktestMarketDataPublisher(backTestFile, mdQueue);

        // 2) Trade‑signal writer (shared)
        TradeSignalEvents tsWriter = tsQueue.createAppender().methodWriterBuilder(TradeSignalEvents.class).build();

        // 3) Three independent strategies
        StrategyConsumer s1 = new StrategyConsumer("BTC-USD", tsWriter);
        StrategyConsumer s2 = new StrategyConsumer("ETH-USD", tsWriter);
        StrategyConsumer s3 = new StrategyConsumer("LTC-USD", tsWriter);

        // 4) Fan‑out
        FanOutRunnable fanOut = new FanOutRunnable(mdQueue, s1, s2, s3);

        // 5) Sink
        TradeSignalSink sink = new TradeSignalSink();
        // Reader thread for sink
        Runnable sinkReader = () -> {
            var tailer = tsQueue.createTailer();
            var reader = tailer.methodReader(sink);
            while(true) if (!reader.readOne()) net.openhft.chronicle.core.Jvm.pause(1);
        };

        ThreadFactory tf = new ThreadFactory() {
            private final AtomicInteger id = new AtomicInteger();

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "router-" + id.incrementAndGet());
                t.setDaemon(true);
                return t;
            }
        };
        ExecutorService exec = new ThreadPoolExecutor(6,                     // core threads
                6,                     // max threads – fixed-size
                0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(), tf);

        CountDownLatch stopLatch = new CountDownLatch(1);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOG.info("Shutdown requested – stopping executor...");
            exec.shutdownNow();
            stopLatch.countDown();          // release main thread
        }));

        exec.submit(publisher);
        exec.submit(fanOut);
        exec.submit(s1);
        exec.submit(s2);
        exec.submit(s3);
        exec.submit(sinkReader);

        LOG.info("Chronicle router up – Ctrl‑C to exit");
        stopLatch.await();
    }
}