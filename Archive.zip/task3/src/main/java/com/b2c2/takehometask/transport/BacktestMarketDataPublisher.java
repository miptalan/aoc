package com.b2c2.takehometask.transport;

import com.b2c2.takehometask.ConversionUtils;
import com.b2c2.takehometask.api.MarketDataEvents;
import net.openhft.chronicle.queue.ChronicleQueue;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;

public class BacktestMarketDataPublisher implements Runnable {
    private static final Logger LOG = LoggerFactory.getLogger(BacktestMarketDataPublisher.class);

    private final BufferedReader reader;
    private final MarketDataEvents writer;
    private volatile boolean running = true;

    public BacktestMarketDataPublisher(String backtestFile, ChronicleQueue queue) throws IOException {
        this.reader = new BufferedReader(new InputStreamReader(Objects.requireNonNull(getClass().getClassLoader().getResourceAsStream(backtestFile))));
        this.writer = queue.createAppender().methodWriterBuilder(MarketDataEvents.class).build();
    }

    @Override
    public void run() {
        String line;
        try {
            while (running && (line = reader.readLine()) != null) {
                if (line.isBlank() || line.startsWith("#")) continue;
                LOG.trace("Read line: {}", line);
                String[] tokens = line.split(";");
                if (tokens.length != 2) {
                    LOG.warn("Invalid line: {}", line);
                    continue;
                }

                JSONObject json = new JSONObject(tokens[1]);
                String type = json.getString("type");
                if (!type.equals("ticker")) {
                    LOG.warn("Invalid line type: {}", type);
                    continue;
                }

                String productId = json.getString("product_id");
                long timestampMicros = ConversionUtils.parseMillis(tokens[0]);
                long price = ConversionUtils.priceAsLong(json.getDouble("price"));


                writer.onMarketData(timestampMicros, productId, price);
            }
        } catch (IOException | RuntimeException e) {
            LOG.error("Publisher stopped due to error", e);
        }
        LOG.info("Publisher finished");
    }

    public void stop() {
        running = false;
    }
}
