package com.b2c2.takehometask.api;

public interface MarketDataEvents {
    void onMarketData(long timestampMicros, String productId, long price);
}
