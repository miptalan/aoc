package com.b2c2.takehometask.transport;

import com.b2c2.takehometask.api.MarketDataEvents;
import net.openhft.chronicle.bytes.MethodReader;
import net.openhft.chronicle.queue.ChronicleQueue;
import net.openhft.chronicle.queue.ExcerptTailer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FanOutRunnable implements Runnable {
    private static final Logger LOG = LoggerFactory.getLogger(FanOutRunnable.class);

    private final MethodReader reader;
    private volatile boolean running = true;

    public FanOutRunnable(ChronicleQueue queue, MarketDataEvents... consumers) {
        ExcerptTailer tailer = queue.createTailer();
        this.reader = tailer.methodReader((Object[])consumers);
    }

    @Override public void run() {
        while (running) {
            if (!reader.readOne())
                net.openhft.chronicle.core.Jvm.pause(1); // micro‑pause
        }
    }

    public void stop() { running = false; }
}