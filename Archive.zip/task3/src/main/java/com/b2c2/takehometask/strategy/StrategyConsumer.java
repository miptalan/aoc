package com.b2c2.takehometask.strategy;

import com.b2c2.takehometask.api.MarketDataEvents;
import com.b2c2.takehometask.api.TradeSignalEvents;

public class StrategyConsumer implements MarketDataEvents, Runnable {
    private final String product;
    private final TradeSignalEvents signalWriter;
    private volatile boolean running = true;

    public StrategyConsumer(String product, TradeSignalEvents writer) {
        this.product = product;
        this.signalWriter = writer;
    }

    @Override public void onMarketData(long ts, String prod, long price) {
        if (!prod.equals(product)) return;
        signalWriter.onTradeSignal(ts, prod, TradeSignalEvents.Side.HOLD, price);
    }

    @Override public void run() {
        while (running) net.openhft.chronicle.core.Jvm.pause(100000); // spin lightly
    }

    public void stop() { running = false; }
}