package com.b2c2.takehometask.strategy;

import com.b2c2.takehometask.api.TradeSignalEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TradeSignalSink implements TradeSignalEvents, Runnable {
    private static final Logger LOG = LoggerFactory.getLogger(TradeSignalSink.class);
    private volatile boolean running = true;

    @Override public void onTradeSignal(long ts, String prod, Side side, long price) {
        LOG.info("[{}] {} {} @ {}", ts, prod, side, price);
    }

    @Override public void run() {
        while (running) net.openhft.chronicle.core.Jvm.pause(100000);
    }

    public void stop() { running = false; }
}