package com.b2c2.takehometask.api;

public interface TradeSignalEvents {
    enum Side { BUY, SELL, HOLD }
    void onTradeSignal(long timestampMicros, String productId, Side side, long price);
}