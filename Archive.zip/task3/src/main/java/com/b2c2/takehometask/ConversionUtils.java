package com.b2c2.takehometask;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

public final class ConversionUtils {

    public static final long PRICE_SCALE = 100_000_000;

    public static double priceAsDouble(long price) {
        return (double) price / price;
    }

    public static long priceAsLong(double priceDbl) {
        return Math.round(priceDbl * PRICE_SCALE);
    }

    private static final DateTimeFormatter MICRO_ISO_INSTANT =
            new DateTimeFormatterBuilder()
                    .appendInstant(6)      // 6 = microsecond precision (max 9)
                    .toFormatter();

    /**
     * @param epochMicros  microseconds since Unix epoch
     * @return ISO-8601 string like “2025-04-16T12:54:56.607061Z”
     */
    public static String formatEpochMicros(long epochMicros) {
        long seconds      = Math.floorDiv(epochMicros, 1_000_000);
        long microsPart   = Math.floorMod(epochMicros, 1_000_000);
        Instant instant   = Instant.ofEpochSecond(seconds, microsPart * 1_000); // convert µs → ns
        return MICRO_ISO_INSTANT.format(instant);
    }

    public static long parseMicros(String isoDateStringMicros) {
        Instant instant = Instant.parse(isoDateStringMicros);
        return instant.getEpochSecond() * 1_000_000 + instant.getNano() / 1000;
    }

    private static final DateTimeFormatter FLEXIBLE_PARSE = new DateTimeFormatterBuilder()
            .appendPattern("yyyy-MM-dd HH:mm:ss")
            .optionalStart()
            .appendFraction(ChronoField.MICRO_OF_SECOND, 0, 6, true) // up to 6 digits
            .optionalEnd()
            .toFormatter();

    public static long parseMillis(String customDateStringMillis) {
        LocalDateTime ldt = LocalDateTime.parse(customDateStringMillis, FLEXIBLE_PARSE);
        long epochSeconds = ldt.toEpochSecond(ZoneOffset.UTC);
        int micros = ldt.get(ChronoField.MICRO_OF_SECOND);
        return epochSeconds * 1_000_000L + micros;
    }
}
