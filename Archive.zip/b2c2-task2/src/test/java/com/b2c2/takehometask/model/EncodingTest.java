package com.b2c2.takehometask.model;

import org.agrona.concurrent.UnsafeBuffer;
import org.junit.jupiter.api.Test;

import java.nio.ByteBuffer;

import static com.b2c2.takehometask.model.ConversionUtils.priceAsLong;
import static org.junit.jupiter.api.Assertions.*;

class EncodingTest {
//    @Test
//    public void testMarketDataTickEncoding() {
//        MarketDataTick sender = new MarketDataTick();
//        MarketDataTick receiver = new MarketDataTick();
//        UnsafeBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(MarketDataTick.MESSAGE_SIZE));
//
//        long timestampMicros = System.currentTimeMillis() * 1000;
//        int instrumentId = 1000;
//        long price = priceAsLong(100.0);
//        sender.encode(buffer, 0, timestampMicros, instrumentId, price);
//
//        receiver.wrap(buffer, 0);
//        assertEquals(timestampMicros, receiver.getTimestampMicros());
//        assertEquals(instrumentId, receiver.getInstrumentId());
//        assertEquals(price, receiver.getPrice());
//    }
//
//    @Test
//    public void testTradeSignalEncoding() {
//        TradeSignal sender = new TradeSignal();
//        TradeSignal receiver = new TradeSignal();
//        UnsafeBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(TradeSignal.MESSAGE_SIZE));
//
//        long timestampMicros = System.currentTimeMillis() * 1000;
//        String instrument = "BTC-USD";
//        double rsiScore = 0.8;
//        Side side = Side.Buy;
//        long size = 1;
//        long price = priceAsLong(100.0);
//        sender.encode(buffer, 0, timestampMicros, instrument, rsiScore, side, size, price);
//
//        receiver.wrap(buffer, 0);
//
//        assertEquals(timestampMicros, receiver.getTimestampMicros());
//        assertEquals(instrument, receiver.getInstrument());
//        assertEquals(rsiScore, receiver.getRsiScore());
//        assertEquals(side, receiver.getSide());
//        assertEquals(size, receiver.getSize());
//        assertEquals(price, receiver.getPrice());
//    }
}