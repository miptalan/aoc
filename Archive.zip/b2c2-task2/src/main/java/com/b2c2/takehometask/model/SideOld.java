package com.b2c2.takehometask.model;

public enum SideOld {
    Buy((byte) 1), Sell((byte) 2);

    private final byte id;

    SideOld(byte id) {
        this.id = id;
    }

    byte id() {
        return id;
    }

    static SideOld fromId(byte id) {
        return switch (id) {
            case (byte) 1 -> Buy;
            case (byte) 2 -> Sell;
            default -> throw new IllegalArgumentException("Unsupported side ID: " + id);
        };
    }
}
