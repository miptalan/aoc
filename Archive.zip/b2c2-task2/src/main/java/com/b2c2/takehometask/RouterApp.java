package com.b2c2.takehometask;

import io.aeron.Aeron;
import io.aeron.Publication;
import io.aeron.Subscription;
import io.aeron.driver.MediaDriver;
import io.aeron.driver.ThreadingMode;
import org.agrona.collections.Int2ObjectHashMap;
import org.agrona.collections.Object2IntHashMap;
import org.agrona.concurrent.AgentRunner;
import org.agrona.concurrent.BusySpinIdleStrategy;
import org.agrona.concurrent.ShutdownSignalBarrier;
import org.agrona.concurrent.YieldingIdleStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class RouterApp {

    private static final Logger LOG = LoggerFactory.getLogger(RouterApp.class);

    public static void main(String[] args) throws Exception {
        String channel = "aeron:ipc";
        int streamIdCounter = 1000;
        String[] instruments = new String[]{"BTC-USD", "ETH-USD", "LTC-USD"};
        String backtestFile = "historical_prices.txt";

        ShutdownSignalBarrier shutdownSignalBarrier = new ShutdownSignalBarrier();
        MediaDriver.Context mediaDriverCtx = new MediaDriver.Context()
                .dirDeleteOnStart(true)
                .threadingMode(ThreadingMode.DEDICATED);

        try (MediaDriver mediaDriver = MediaDriver.launchEmbedded(mediaDriverCtx);
             Aeron aeron = Aeron.connect(new Aeron.Context().aeronDirectoryName(mediaDriver.aeronDirectoryName()))
        ) {
            LOG.info("Journals in {}", mediaDriver.aeronDirectoryName());
            List<AgentRunner> agentRunners = new ArrayList<>();

            // setup trade sink
            Subscription tradeSinkSubscription = aeron.addSubscription(channel, streamIdCounter);
            TradeSignalSinkAgent tradeSinkAgent = new TradeSignalSinkAgent(tradeSinkSubscription);
            Publication tradeSinkPublication = aeron.addPublication(channel, streamIdCounter);
            AgentRunner sinkAgentRunner = new AgentRunner(new YieldingIdleStrategy(), Throwable::printStackTrace, null, tradeSinkAgent);
            agentRunners.add(sinkAgentRunner);
            streamIdCounter++;

            Object2IntHashMap<String> imap = new Object2IntHashMap<>(-1);
            Int2ObjectHashMap<Publication> pubMap = new Int2ObjectHashMap<>();

            for (String instrument : instruments) {
                imap.put(instrument.intern(), streamIdCounter);
                StrategyConsumerAgent strategyConsumerAgent = new StrategyConsumerAgent(instrument, aeron.addSubscription(channel, streamIdCounter), tradeSinkPublication);
                Publication marketDataFeed = aeron.addPublication(channel, streamIdCounter);
                pubMap.put(streamIdCounter, marketDataFeed);

                agentRunners.add(new AgentRunner(new BusySpinIdleStrategy(), Throwable::printStackTrace, null, strategyConsumerAgent));
                streamIdCounter++;
            }

            BacktestMarketDataPublisherAgent mdAgent = new BacktestMarketDataPublisherAgent(imap, pubMap, shutdownSignalBarrier, backtestFile);
            agentRunners.add(new AgentRunner(new YieldingIdleStrategy(), Throwable::printStackTrace, null, mdAgent));

            LOG.info("Starting agentRunners");
            AgentRunner.startOnThread(sinkAgentRunner);

            for (int i = agentRunners.size() - 1; i >= 0; i--) {
                AgentRunner.startOnThread(agentRunners.get(i));
            }
        }

        LOG.info("RouterApp is up. Ctrl‑C to exit.");
        shutdownSignalBarrier.await();
        LOG.info("Shutting down");
        System.err.println("Shut");
        System.exit(0);
    }
}