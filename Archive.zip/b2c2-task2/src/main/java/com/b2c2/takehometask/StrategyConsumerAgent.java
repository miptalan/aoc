package com.b2c2.takehometask;

import com.b2c2.takehometask.sbe.*;
import io.aeron.FragmentAssembler;
import io.aeron.Publication;
import io.aeron.Subscription;
import io.aeron.logbuffer.Header;
import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.Agent;
import org.agrona.concurrent.AgentTerminationException;
import org.agrona.concurrent.UnsafeBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.util.random.RandomGenerator;

public class StrategyConsumerAgent implements Agent {
    private static final Logger LOG = LoggerFactory.getLogger(StrategyConsumerAgent.class);

    private final String instrument;
    private final Subscription marketDataFeed;
    private final Publication tradeSink;
    private final String roleName;

    private final MessageHeaderDecoder hdrDec = new MessageHeaderDecoder();
    private final MessageHeaderEncoder hdrEnc = new MessageHeaderEncoder();
    private final MarketDataTickDecoder tickDec = new MarketDataTickDecoder();
    private final TradeSignalEncoder tradeEnc = new TradeSignalEncoder();
    private final MutableDirectBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(256));
    private final FragmentAssembler fragmentHandler = new FragmentAssembler(this::handler);

    public StrategyConsumerAgent(String instrument, Subscription marketDataFeed, Publication tradeSink) {
        this.instrument = instrument;
        this.marketDataFeed = marketDataFeed;
        this.tradeSink = tradeSink;

        this.roleName = "strategy-" + instrument + "-" + marketDataFeed.streamId();
        LOG.info("Creating {}, MD sub connected: {}, TS pub connected: {}", roleName, marketDataFeed.isConnected(), tradeSink.isConnected());
    }

    @Override
    public int doWork() {
        return marketDataFeed.poll(fragmentHandler, 1);
    }

    private void handler(DirectBuffer directBuffer, int offset, int length, Header header) {
        try {
            hdrDec.wrap(directBuffer, offset);
            if (hdrDec.templateId() != MarketDataTickDecoder.TEMPLATE_ID) {
                LOG.error("Received unknown message: templateId={}", hdrDec.templateId());
                return;
            }
            tickDec.wrap(directBuffer, offset + MessageHeaderDecoder.ENCODED_LENGTH, hdrDec.blockLength(), hdrDec.version());
            LOG.trace("Received market data tick: {}", tickDec);

            long timestampMicros = tickDec.timestampMicros();
            long price = tickDec.price();
            tradeEnc.wrapAndApplyHeader(buffer, 0, hdrEnc);
            tradeEnc
                    .strategyName("RSI")
                    .timestampMicros(timestampMicros)
                    .instrument(instrument)
                    .price(price)
                    .size(1);

            if (RandomGenerator.getDefault().nextBoolean()) {
                tradeEnc.rsiScore(0.8).side(SideEnum.Buy);
            } else {
                tradeEnc.rsiScore(0.1).side(SideEnum.Sell);
            }
            long result = tradeSink.offer(buffer, 0, hdrEnc.encodedLength() + tradeEnc.encodedLength());
            if (LOG.isTraceEnabled()) {
                if (result > 0) {
                    LOG.trace("[{}] Sent trade signal for: {}", instrument, tradeEnc);
                } else {
                    LOG.trace("[{}] Cannot send trade signal, result {}: {}", instrument, result, tradeEnc);
                }
            }
        } catch (Exception e) {
            LOG.error("SMth happened", e);
            throw new AgentTerminationException(e);
        }
    }


    @Override
    public String roleName() {
        return roleName;
    }
}