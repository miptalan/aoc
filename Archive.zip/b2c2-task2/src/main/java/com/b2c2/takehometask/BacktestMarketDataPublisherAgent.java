package com.b2c2.takehometask;

import com.b2c2.takehometask.model.ConversionUtils;
import com.b2c2.takehometask.sbe.MarketDataTickEncoder;
import com.b2c2.takehometask.sbe.MessageHeaderEncoder;
import io.aeron.Publication;
import org.agrona.MutableDirectBuffer;
import org.agrona.collections.Int2ObjectHashMap;
import org.agrona.collections.Object2IntHashMap;
import org.agrona.concurrent.Agent;
import org.agrona.concurrent.ShutdownSignalBarrier;
import org.agrona.concurrent.UnsafeBuffer;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.stream.Collectors;

public class BacktestMarketDataPublisherAgent implements Agent {
    private static final Logger LOG = LoggerFactory.getLogger(BacktestMarketDataPublisherAgent.class);
    private static final int BATCH_SIZE = 1;

    private final ShutdownSignalBarrier barrier;
    private final Object2IntHashMap<String> imap;
    private final Int2ObjectHashMap<Publication> publications;

    private final MessageHeaderEncoder hdr = new MessageHeaderEncoder();
    private final MarketDataTickEncoder tickEnc = new MarketDataTickEncoder();
    private final MutableDirectBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(128));
    private final BufferedReader reader;

    public BacktestMarketDataPublisherAgent(Object2IntHashMap<String> imap,
                                            Int2ObjectHashMap<Publication> publications,
                                            ShutdownSignalBarrier barrier, String backtestFile) {
        this.imap = imap;
        this.publications = publications;
        this.barrier = barrier;
        this.reader = new BufferedReader(new InputStreamReader(Objects.requireNonNull(getClass().getClassLoader().getResourceAsStream(backtestFile))));

        LOG.info("Creating {}, reading from {}, MD pubs connected: {}", roleName(),
                backtestFile, publications.values().stream().map(Publication::isConnected).collect(Collectors.toList()));
    }

    @Override
    public int doWork() {
        try {
            int sent = 0;
            String line = null;
            while (sent < BATCH_SIZE && (line = reader.readLine()) != null) {
                LOG.trace("Read line: {}", line);
                if (line.isBlank() || line.startsWith("#")) continue; // skip blanks and comments

                String[] tokens = line.split(";");
                if (tokens.length != 2) {
                    LOG.warn("Invalid line: {}", line);
                    continue;
                }

                JSONObject json = new JSONObject(tokens[1]);
                String type = json.getString("type");
                if (!type.equals("ticker")) {
                    LOG.warn("Invalid line type: {}", type);
                    continue;
                }

                String productId = json.getString("product_id");
                int instrumentId = imap.get(productId);
                if (instrumentId < 0) {
                    LOG.warn("Unknown productId: {}", productId);
                    continue;
                }

                Publication pub = publications.get(instrumentId);
                if (pub == null) {
                    LOG.warn("No publication for productId/instrumentId: {}/{}", productId, instrumentId);
                    continue;
                }

                if (!pub.isConnected()) {
                    LOG.warn("Publication is not connected for productId/instrumentId: {}/{}", productId, instrumentId);
                    return 0;
                }

                long timestampMicros = ConversionUtils.parseMillis(tokens[0]);
                long price = ConversionUtils.priceAsLong(json.getDouble("price"));

                tickEnc.wrapAndApplyHeader(buffer, 0, hdr);
                tickEnc
                        .timestampMicros(timestampMicros)
                        .instrumentId(instrumentId)
                        .price(price);
                long result = pub.offer(buffer, 0, hdr.encodedLength() + tickEnc.encodedLength());
                if (result > 0) {
                    LOG.trace("[{}] Tick sent: {}", productId, tickEnc);
                } else {
                    LOG.trace("[{}] Cannot send tick, result {}: {}", productId, result, tickEnc);
                    return 0;
                }

                sent++;
            }

            if (line == null) {
                return 0;
            }

            return sent;
        } catch (IOException e) {
            LOG.error("I/O error in backtest publisher", e);
            return 0;
        } catch (NumberFormatException ex) {
            LOG.error("Bad numeric in input", ex);
            return 0;
        }
    }


    @Override
    public String roleName() {
        return "market-data-publisher";
    }
}