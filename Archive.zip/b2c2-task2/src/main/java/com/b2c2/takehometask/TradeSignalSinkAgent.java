package com.b2c2.takehometask;

import com.b2c2.takehometask.sbe.*;
import io.aeron.FragmentAssembler;
import io.aeron.Subscription;
import io.aeron.logbuffer.Header;
import org.agrona.DirectBuffer;
import org.agrona.concurrent.Agent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TradeSignalSinkAgent implements Agent {

    private static final Logger LOG = LoggerFactory.getLogger(TradeSignalSinkAgent.class);
    private final Subscription sub;
    private final MessageHeaderDecoder hdrDec = new MessageHeaderDecoder();
    private final TradeSignalDecoder tradeDec = new TradeSignalDecoder();
    private final FragmentAssembler fragmentHandler = new FragmentAssembler(this::handler);

    public TradeSignalSinkAgent(Subscription sub) {
        this.sub = sub;
        LOG.info("Creating {}, TS sub connected: {}", roleName(), sub.isConnected());
    }

    @Override
    public int doWork() {
        return sub.poll(fragmentHandler, 1);
    }

    private void handler(final DirectBuffer buffer, final int offset, final int length, final Header header) {
        hdrDec.wrap(buffer, offset);
        if (hdrDec.templateId() != TradeSignalDecoder.TEMPLATE_ID) {
            LOG.error("Received unknown message: templateId={}", hdrDec.templateId());
            return;
        }
        tradeDec.wrap(buffer, offset + MessageHeaderDecoder.ENCODED_LENGTH, hdrDec.blockLength(), hdrDec.version());
        LOG.debug("Received trade signal: {}", tradeDec);
    }


    @Override
    public String roleName() {
        return "trade-signal-sink";
    }
}