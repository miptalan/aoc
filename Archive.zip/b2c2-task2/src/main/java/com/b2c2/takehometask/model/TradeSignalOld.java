package com.b2c2.takehometask.model;

import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;

import java.nio.ByteBuffer;

import static com.b2c2.takehometask.model.ConversionUtils.*;

public class TradeSignalOld {
    public static final String RSI = "RSI";

    //[TIMESTAMP];STRATEGY_NAME;INSTRUMENT;RSI_SCORE;SIDE;SIZE;PRICE
    private static final int TIMESTAMP_MICROS_OFFSET = 0;
    private static final int STRATEGY_NAME_OFFSET = TIMESTAMP_MICROS_OFFSET + 8;
    private static final int INSTRUMENT_OFFSET = STRATEGY_NAME_OFFSET + 3; // always RSI
    private static final int RSI_SCORE_OFFSET = INSTRUMENT_OFFSET + 14;
    private static final int SIDE_OFFSET = RSI_SCORE_OFFSET + 8;
    private static final int SIZE_OFFSET = SIDE_OFFSET + 1;
    private static final int PRICE_OFFSET = SIZE_OFFSET + 8;

    public static final int MESSAGE_SIZE = PRICE_OFFSET + 8;

    // flyweight
    private final UnsafeBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(MESSAGE_SIZE));

    public void encode(MutableDirectBuffer destination, int offset,
                       long timestampMicros, String instrument, double rsiScore,
                       SideOld side, long size, long price) {
        destination.putLong(offset + TIMESTAMP_MICROS_OFFSET, timestampMicros);
        destination.putStringAscii(offset + STRATEGY_NAME_OFFSET, RSI);
        destination.putStringAscii(offset + INSTRUMENT_OFFSET, instrument);

        destination.putDouble(offset + RSI_SCORE_OFFSET, rsiScore);
        destination.putInt(offset + SIDE_OFFSET, side.id());
        destination.putLong(offset + SIZE_OFFSET, size);
        destination.putLong(offset + PRICE_OFFSET, price);
    }

    public void wrap(DirectBuffer source, int offset) {
        buffer.wrap(source, offset, MESSAGE_SIZE);
    }

    public long getTimestampMicros() {
        return buffer.getLong(TIMESTAMP_MICROS_OFFSET);
    }

    public String getStrategyName() {
        return buffer.getStringAscii(STRATEGY_NAME_OFFSET);
    }

    public String getInstrument() {
        return buffer.getStringAscii(INSTRUMENT_OFFSET);
    }

    public double getRsiScore() {
        return buffer.getDouble(RSI_SCORE_OFFSET);
    }

    public SideOld getSide() {
        return SideOld.fromId(buffer.getByte(SIDE_OFFSET));
    }

    public long getSize() {
        return buffer.getLong(SIZE_OFFSET);
    }

    public long getPrice() {
        return buffer.getLong(PRICE_OFFSET);
    }

    @Override
    public String toString() {
        return "TradeSignal{" +
                "timestamp=" + formatEpochMicros(getTimestampMicros()) +
                ",strategy=" + getStrategyName() +
                ",instrument=" + getInstrument() +
                ",rsiScore=" + getRsiScore() +
                ",side=" + getSide() +
                ",size=" + getSize() +
                ",price=" + priceAsDouble(getPrice()) +
                '}';
    }
}