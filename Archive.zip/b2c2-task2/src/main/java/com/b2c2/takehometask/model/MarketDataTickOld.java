package com.b2c2.takehometask.model;

import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;

import java.nio.ByteBuffer;

import static com.b2c2.takehometask.model.ConversionUtils.formatEpochMicros;
import static com.b2c2.takehometask.model.ConversionUtils.priceAsDouble;

public class MarketDataTickOld {

    private static final int TIMESTAMP_MICROS_OFFSET = 0;
    private static final int INSTRUMENT_ID_OFFSET = TIMESTAMP_MICROS_OFFSET + 8;
    private static final int PRICE_OFFSET = INSTRUMENT_ID_OFFSET + 4;

    public static final int MESSAGE_SIZE = PRICE_OFFSET + 8;

    // flyweight
    private final UnsafeBuffer buffer = new UnsafeBuffer(ByteBuffer.allocateDirect(MESSAGE_SIZE));

    public void encode(MutableDirectBuffer destination, int offset, long timestampMicros, int instrumentId, long price) {
        destination.putLong(offset + TIMESTAMP_MICROS_OFFSET, timestampMicros);
        destination.putInt(offset + INSTRUMENT_ID_OFFSET, instrumentId);
        destination.putLong(offset + PRICE_OFFSET, price);
    }

    public void wrap(DirectBuffer source, int offset) {
        buffer.wrap(source, offset, MESSAGE_SIZE);
    }

    public long getTimestampMicros() {
        return buffer.getLong(TIMESTAMP_MICROS_OFFSET);
    }

    public int getInstrumentId() {
        return buffer.getInt(INSTRUMENT_ID_OFFSET);
    }

    public long getPrice() {
        return buffer.getLong(PRICE_OFFSET);
    }

    @Override
    public String toString() {
        return "MarketDataTick{" +
                "timestamp=" + formatEpochMicros(getTimestampMicros()) +
                ",instrumentId=" + getInstrumentId() +
                ",price=" + priceAsDouble(getPrice()) +
                '}';
    }
}