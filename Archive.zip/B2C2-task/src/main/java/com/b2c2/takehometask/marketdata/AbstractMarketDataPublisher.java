package com.b2c2.takehometask.marketdata;

import io.aeron.Publication;
import org.agrona.concurrent.IdleStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public abstract class AbstractMarketDataPublisher implements MarketDataPublisher {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractMarketDataPublisher.class);
    private final Publication channel;
    private final IdleStrategy idleStrategy;

    public AbstractMarketDataPublisher(Publication channel, IdleStrategy idleStrategy) {
        this.channel = channel;
        this.idleStrategy = idleStrategy;
    }

    @Override
    abstract public void publish() throws IOException;

    @Override
    public void close() {
        channel.close();
    }

    @Override
    public void run() {
        try {
            publish();
        } catch (Exception e) {
            LOG.error("Exception during market data publishing", e);
            throw new RuntimeException(e);
        }
    }

    public Publication getChannel() {
        return channel;
    }

    public IdleStrategy getIdleStrategy() {
        return idleStrategy;
    }
}
