package com.b2c2.takehometask;

import com.b2c2.takehometask.marketdata.AbstractMarketDataPublisher;
import com.b2c2.takehometask.marketdata.BacktestMarketDataPublisherImpl;
import io.aeron.Aeron;
import io.aeron.driver.MediaDriver;
import io.aeron.driver.ThreadingMode;
import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.BusySpinIdleStrategy;
import org.agrona.concurrent.IdleStrategy;
import org.agrona.concurrent.ShutdownSignalBarrier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MultiStrategyTradingSystemApp {
    private static final Logger LOG = LoggerFactory.getLogger(MultiStrategyTradingSystemApp.class);

    enum Mode { BACKTEST, REALTIME }

    private static final String[] INSTRUMENTS = {"BTC-USD", "ETH-USD", "LTC-USD"};

    public static final String MD_CHANNEL = "aeron:ipc";

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java -jar strategy.jar <mode>");
            System.err.println("\tmode: backtest | realtime");
            System.exit(1);
        }

        Mode mode = Mode.valueOf(args[0].toLowerCase());
        if (LOG.isInfoEnabled()) {
            LOG.info("Starting MSTS in {} mode with {} strategy instances", mode, INSTRUMENTS.length);
        }

        final IdleStrategy idleStrategySend = new BusySpinIdleStrategy();
        final IdleStrategy idleStrategyReceive = new BusySpinIdleStrategy();
        final ShutdownSignalBarrier barrier = new ShutdownSignalBarrier();

        //construct Media Driver, cleaning up media driver folder on start/stop
        final MediaDriver.Context mediaDriverCtx = new MediaDriver.Context()
                .dirDeleteOnStart(true)
                .threadingMode(ThreadingMode.SHARED)
                .sharedIdleStrategy(new BusySpinIdleStrategy())
                .dirDeleteOnShutdown(true);
        final MediaDriver mediaDriver = MediaDriver.launchEmbedded(mediaDriverCtx);

        //construct Aeron, pointing at the media driver's folder
        final Aeron.Context aeronCtx = new Aeron.Context()
                .aeronDirectoryName(mediaDriver.aeronDirectoryName());
        final Aeron aeron = Aeron.connect(aeronCtx);
    }
}
