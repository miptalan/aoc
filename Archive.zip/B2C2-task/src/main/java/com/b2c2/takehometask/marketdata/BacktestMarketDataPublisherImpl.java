package com.b2c2.takehometask.marketdata;

import com.b2c2.takehometask.messages.MarketDataTickEncoder;
import com.b2c2.takehometask.messages.MessageHeaderEncoder;
import io.aeron.Publication;
import org.agrona.concurrent.IdleStrategy;
import org.agrona.concurrent.UnsafeBuffer;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;

public class BacktestMarketDataPublisherImpl extends AbstractMarketDataPublisher {
    private static final int OUT_BUFFER_SIZE = MessageHeaderEncoder.ENCODED_LENGTH + MarketDataTickEncoder.BLOCK_LENGTH;
    private final Path inputFilePath;
    private final UnsafeBuffer out = new UnsafeBuffer(ByteBuffer.allocateDirect(OUT_BUFFER_SIZE));
    private final MessageHeaderEncoder hdr = new MessageHeaderEncoder();
    private final MarketDataTickEncoder enc = new MarketDataTickEncoder();

    public BacktestMarketDataPublisherImpl(Publication channel, IdleStrategy idleStrategy, Path inputFilePath) {
        super(channel, idleStrategy);
        this.inputFilePath = inputFilePath;
    }

    @Override
    public void publish() throws IOException {
        try (BufferedReader br = Files.newBufferedReader(inputFilePath)) {
            String line;
            while ((line = br.readLine()) != null) {
                var json = new JSONObject(line);

                Instant instant = Instant.parse(json.getString("time"));
                long nanos = instant.getEpochSecond() * 1_000_000_000L + instant.getNano();

                enc.wrapAndApplyHeader(out, 0, hdr)
                        .timestamp_ns(nanos)
                        .product_id(json.getString("product_id"))
                        .price().mantissa((long) json.getDouble("price") * PRICE_SCALE);

                while (getChannel().offer(out, 0, OUT_BUFFER_SIZE) < 0) {
                    getIdleStrategy().idle();
                }
            }
        }
    }
}
