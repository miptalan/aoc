package com.b2c2.takehometask.marketdata;

import java.io.IOException;

interface MarketDataPublisher extends Runnable, AutoCloseable {
    long PRICE_SCALE = 100_000_000L;

    void publish() throws IOException;
}
